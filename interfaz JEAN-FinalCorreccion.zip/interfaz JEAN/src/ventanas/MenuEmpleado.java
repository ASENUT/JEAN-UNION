package ventanas;

public class MenuEmpleado extends javax.swing.JFrame {

    public MenuEmpleado() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitulo = new javax.swing.JLabel();
        btnLogOut = new javax.swing.JButton();
        btnCerrar = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        lblClientes = new javax.swing.JLabel();
        btnClientes = new javax.swing.JButton();
        lblHistoria = new javax.swing.JLabel();
        lblHistNut = new javax.swing.JLabel();
        btnHistNut = new javax.swing.JButton();
        lblHistoria1 = new javax.swing.JLabel();
        lblHistCosmet = new javax.swing.JLabel();
        btnHistCosmet = new javax.swing.JButton();
        lblVentas = new javax.swing.JLabel();
        btnVentas = new javax.swing.JButton();
        lblAgendar = new javax.swing.JLabel();
        lblCitas = new javax.swing.JLabel();
        btnAgenda = new javax.swing.JButton();
        lblFondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setName("Menu2"); // NOI18N
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblTitulo.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblTitulo.setText("ASESORÍA NUTRICIONAL");
        getContentPane().add(lblTitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(15, 8, -1, -1));

        btnLogOut.setForeground(new java.awt.Color(255, 255, 255));
        btnLogOut.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/CerrarSesion.png"))); // NOI18N
        btnLogOut.setToolTipText("REGRESAR");
        btnLogOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogOutActionPerformed(evt);
            }
        });
        getContentPane().add(btnLogOut, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 6, 20, 20));

        btnCerrar.setForeground(new java.awt.Color(255, 255, 255));
        btnCerrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Salir.png"))); // NOI18N
        btnCerrar.setToolTipText("CERRAR");
        btnCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCerrarActionPerformed(evt);
            }
        });
        getContentPane().add(btnCerrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 6, 20, 20));

        jSeparator1.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        getContentPane().add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 30, 440, 1));

        jSeparator2.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        getContentPane().add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 32, 440, 1));

        lblClientes.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        lblClientes.setText("CLIENTES");
        getContentPane().add(lblClientes, new org.netbeans.lib.awtextra.AbsoluteConstraints(26, 40, -1, -1));

        btnClientes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Cliente.png"))); // NOI18N
        btnClientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClientesActionPerformed(evt);
            }
        });
        getContentPane().add(btnClientes, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 80, 80));

        lblHistoria.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        lblHistoria.setText("HISTORIAL");
        getContentPane().add(lblHistoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(117, 37, -1, -1));

        lblHistNut.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        lblHistNut.setText("NUTRICIONAL");
        getContentPane().add(lblHistNut, new org.netbeans.lib.awtextra.AbsoluteConstraints(106, 47, -1, -1));

        btnHistNut.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Nutricional.png"))); // NOI18N
        btnHistNut.setMaximumSize(new java.awt.Dimension(83, 57));
        btnHistNut.setMinimumSize(new java.awt.Dimension(83, 57));
        btnHistNut.setPreferredSize(new java.awt.Dimension(83, 57));
        btnHistNut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHistNutActionPerformed(evt);
            }
        });
        getContentPane().add(btnHistNut, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 60, 80, 80));

        lblHistoria1.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        lblHistoria1.setText("HISTORIAL");
        getContentPane().add(lblHistoria1, new org.netbeans.lib.awtextra.AbsoluteConstraints(205, 37, -1, -1));

        lblHistCosmet.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        lblHistCosmet.setText("COSMETOLOGICA");
        getContentPane().add(lblHistCosmet, new org.netbeans.lib.awtextra.AbsoluteConstraints(185, 47, -1, -1));

        btnHistCosmet.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Cosmetologico.png"))); // NOI18N
        btnHistCosmet.setMaximumSize(new java.awt.Dimension(83, 57));
        btnHistCosmet.setMinimumSize(new java.awt.Dimension(83, 57));
        btnHistCosmet.setPreferredSize(new java.awt.Dimension(83, 57));
        btnHistCosmet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHistCosmetActionPerformed(evt);
            }
        });
        getContentPane().add(btnHistCosmet, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 60, 80, 80));

        lblVentas.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        lblVentas.setText("VENTAS");
        getContentPane().add(lblVentas, new org.netbeans.lib.awtextra.AbsoluteConstraints(302, 40, -1, -1));

        btnVentas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Ventas.png"))); // NOI18N
        btnVentas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVentasActionPerformed(evt);
            }
        });
        getContentPane().add(btnVentas, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 60, 80, 80));

        lblAgendar.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        lblAgendar.setText("AGENDAR");
        getContentPane().add(lblAgendar, new org.netbeans.lib.awtextra.AbsoluteConstraints(387, 37, -1, -1));

        lblCitas.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        lblCitas.setText("CITAS");
        getContentPane().add(lblCitas, new org.netbeans.lib.awtextra.AbsoluteConstraints(395, 47, -1, -1));

        btnAgenda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Calendario.png"))); // NOI18N
        btnAgenda.setMaximumSize(new java.awt.Dimension(83, 57));
        btnAgenda.setMinimumSize(new java.awt.Dimension(83, 57));
        btnAgenda.setPreferredSize(new java.awt.Dimension(83, 57));
        btnAgenda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgendaActionPerformed(evt);
            }
        });
        getContentPane().add(btnAgenda, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 60, 80, 80));

        lblFondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        getContentPane().add(lblFondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 460, 150));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnLogOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogOutActionPerformed
        Interfaz i = new Interfaz();
        i.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnLogOutActionPerformed

    private void btnCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarActionPerformed
        System.exit(0);
    }//GEN-LAST:event_btnCerrarActionPerformed

    private void btnClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClientesActionPerformed
        DatosGenerales dg = new DatosGenerales();
        dg.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnClientesActionPerformed

    private void btnHistNutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHistNutActionPerformed
	TratamientoNutricional.cedulaFichaTN = "";
        TratamientoNutricional tm = new TratamientoNutricional();
        tm.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnHistNutActionPerformed

    private void btnHistCosmetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHistCosmetActionPerformed
        TratamientoCosmetologico tc = new TratamientoCosmetologico();
        tc.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnHistCosmetActionPerformed

    private void btnVentasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVentasActionPerformed
        Ventas v = new Ventas();
        v.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnVentasActionPerformed

    private void btnAgendaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgendaActionPerformed
        Citas c = new Citas();
        c.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnAgendaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MenuEmpleado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MenuEmpleado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MenuEmpleado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MenuEmpleado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuEmpleado().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgenda;
    private javax.swing.JButton btnCerrar;
    private javax.swing.JButton btnClientes;
    private javax.swing.JButton btnHistCosmet;
    private javax.swing.JButton btnHistNut;
    private javax.swing.JButton btnLogOut;
    private javax.swing.JButton btnVentas;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JLabel lblAgendar;
    private javax.swing.JLabel lblCitas;
    private javax.swing.JLabel lblClientes;
    private javax.swing.JLabel lblFondo;
    private javax.swing.JLabel lblHistCosmet;
    private javax.swing.JLabel lblHistNut;
    private javax.swing.JLabel lblHistoria;
    private javax.swing.JLabel lblHistoria1;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JLabel lblVentas;
    // End of variables declaration//GEN-END:variables
}
