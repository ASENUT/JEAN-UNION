package ventanas;

import java.awt.Graphics;
import java.awt.PrintJob;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class FichaNutricional extends javax.swing.JFrame {

    static String cedulaficha = "";
    static String tratamientoficha = "";

    public FichaNutricional() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        txtBusqueda = new javax.swing.JTextField();
        btnBusqueda = new javax.swing.JButton();
        cbxTratamientos = new javax.swing.JComboBox();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        btnImprimir = new javax.swing.JMenu();
        btnCargar = new javax.swing.JMenu();
        btnGestionar = new javax.swing.JMenu();
        btnRegresar = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Fecha", "Tratamiento", "Costo Total", "Abono", "Saldo"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 630, 230));

        txtBusqueda.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtBusquedaFocusLost(evt);
            }
        });
        getContentPane().add(txtBusqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, 120, 30));

        btnBusqueda.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnBusqueda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Lupa.jpg"))); // NOI18N
        btnBusqueda.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBusquedaMouseClicked(evt);
            }
        });
        getContentPane().add(btnBusqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 20, 30, 30));

        cbxTratamientos.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        getContentPane().add(cbxTratamientos, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 20, 130, 30));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel2.setText("Cedula :");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 60, 30));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        jLabel1.setName("ficha"); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 650, 330));

        jMenuBar1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        btnImprimir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Imprimir.png"))); // NOI18N
        btnImprimir.setText("Imprimir");
        btnImprimir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnImprimirMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnImprimir);

        btnCargar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Update.png"))); // NOI18N
        btnCargar.setText("Cargar");
        btnCargar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnCargarMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnCargar);

        btnGestionar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Save.png"))); // NOI18N
        btnGestionar.setText("Pago");
        btnGestionar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnGestionarMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnGestionar);

        btnRegresar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Back.png"))); // NOI18N
        btnRegresar.setText("Regresar");
        btnRegresar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnRegresarMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnRegresar);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGestionarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnGestionarMouseClicked
        // TODO add your handling code here:
        FichaEconomicaNutri tc = new FichaEconomicaNutri();
        tc.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnGestionarMouseClicked

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
        // TODO add your handling code here:
        if (!TratamientoNutricional.cedulaFichaTN.isEmpty()) {
            txtBusqueda.setText(TratamientoNutricional.cedulaFichaTN);
        }
        
        cbxTratamientos.removeAllItems();

        DefaultTableModel dtm = new DefaultTableModel();
        ResultSet rs;
        try {
            dtm.addColumn("Fecha");
            dtm.addColumn("Tratamiento");
            dtm.addColumn("Costo Total");
            dtm.addColumn("Abono");
            dtm.addColumn("Saldo");
            //rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT P.CEDULA, P.APE_PAC, P.NOM_PAC, TT.NOM_TRATA, U.NOM_USUARIO FROM PACIENTE P, PACIENTE_TRATAMIENTO PT, TIPO_TRATAMIENTO TT, USUARIO U  WHERE P.CEDULA = PT.CEDULA AND PT.COD_TRATAMIENTO = TT.COD_TRATAMIENTO AND TT.COD_TRATA_FACIAL = 1 AND PT.CED_EMPLEADO = U.CED_EMPLEADO");
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT DISTINCT FE.FECHA_TRATA, TT.NOM_TRATA, FE.COSTO_TOTAL, FE.ABONO_MULTA, FE.SALDO FROM FICHA_ECONOMICA FE, PACIENTE_TRATAMIENTO PT, TIPO_TRATAMIENTO TT WHERE TT.COD_TRATA_FACIAL = 1 AND FE.COD_TRATAMIENTO = PT.COD_TRATAMIENTO AND TT.COD_TRATAMIENTO = PT.COD_TRATAMIENTO");
            while (rs.next()) {
                dtm.addRow(new Object[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)});
            }
            jTable1.setModel(dtm);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_formWindowActivated

    private void btnBusquedaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBusquedaMouseClicked
        // TODO add your handling code here:
        ResultSet rs;
        int cont = 0;
        String ced = txtBusqueda.getText();
        cedulaficha = ced;
        
        ///////COMPROBAMOS SI EL PACIENTE EXISTE
        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("select * from PACIENTE WHERE CEDULA = '" + cedulaficha + "'");
            while (rs.next()) {
                cont++;
            }
            if (cont == 0) {
                JOptionPane.showMessageDialog(null, "El paciente no existe");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al cargar datos del paciente");
        }
        ////////////////////////////////////////////////////////////////////////////////
        DefaultTableModel dtm = new DefaultTableModel();
        tratamientoficha = (String) cbxTratamientos.getSelectedItem();
        try {
            dtm.addColumn("Fecha");
            dtm.addColumn("Tratamiento");
            dtm.addColumn("Costo Total");
            dtm.addColumn("Abono");
            dtm.addColumn("Saldo");
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT FE.FECHA_TRATA, TT.NOM_TRATA, "
                    + "FE.COSTO_TOTAL, FE.ABONO_MULTA, FE.SALDO "
                    + "FROM FICHA_ECONOMICA FE, PACIENTE_TRATAMIENTO PT, TIPO_TRATAMIENTO TT "
                    + "WHERE TT.COD_TRATA_FACIAL = 1 AND FE.COD_TRATAMIENTO = PT.COD_TRATAMIENTO "
                    + "AND TT.COD_TRATAMIENTO = PT.COD_TRATAMIENTO AND FE.CEDULA = '" + cedulaficha +
                    "' AND TT.NOM_TRATA = '" + tratamientoficha + "'");
            while (rs.next()) {
                dtm.addRow(new Object[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)});
            }
            jTable1.setModel(dtm);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
        System.out.println(cedulaficha + " | | " + tratamientoficha + "");
    }//GEN-LAST:event_btnBusquedaMouseClicked

    private void btnCargarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCargarMouseClicked
        cbxTratamientos.removeAllItems();;
        txtBusqueda.setText("");
        DefaultTableModel dtm = new DefaultTableModel();
        ResultSet rs;
        try {
            dtm.addColumn("Fecha");
            dtm.addColumn("Tratamiento");
            dtm.addColumn("Costo Total");
            dtm.addColumn("Abono");
            dtm.addColumn("Saldo");
            //rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT P.CEDULA, P.APE_PAC, P.NOM_PAC, TT.NOM_TRATA, U.NOM_USUARIO FROM PACIENTE P, PACIENTE_TRATAMIENTO PT, TIPO_TRATAMIENTO TT, USUARIO U  WHERE P.CEDULA = PT.CEDULA AND PT.COD_TRATAMIENTO = TT.COD_TRATAMIENTO AND TT.COD_TRATA_FACIAL = 1 AND PT.CED_EMPLEADO = U.CED_EMPLEADO");
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT DISTINCT FE.FECHA_TRATA, TT.NOM_TRATA, FE.COSTO_TOTAL, FE.ABONO_MULTA, FE.SALDO FROM FICHA_ECONOMICA FE, PACIENTE_TRATAMIENTO PT, TIPO_TRATAMIENTO TT WHERE TT.COD_TRATA_FACIAL = 1 AND FE.COD_TRATAMIENTO = PT.COD_TRATAMIENTO AND TT.COD_TRATAMIENTO = PT.COD_TRATAMIENTO");
            while (rs.next()) {
                dtm.addRow(new Object[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)});
            }
            jTable1.setModel(dtm);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_btnCargarMouseClicked

    private void btnImprimirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnImprimirMouseClicked
        // TODO add your handling code here:
        PrintJob imprime = getToolkit().getPrintJob(this, evt.getClass().getName(), null);
        if (imprime != null) {
            Graphics pag = imprime.getGraphics();
            if (pag != null) {
                paint(pag); //pinta todo los objetos de la ventana mostrada
                pag.dispose();
            }
        } else {
            //JOptionPane.showMessageDialog(null, “no se imprimo nada”, “imprimir”, JOptionPane.INFORMATION_MESSAGE );
            imprime.end();
        }
        imprime.end();
    }//GEN-LAST:event_btnImprimirMouseClicked

    private void btnRegresarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRegresarMouseClicked
        // TODO add your handling code here:
        TratamientoNutricional tc = new TratamientoNutricional();
        tc.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnRegresarMouseClicked

    private void txtBusquedaFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtBusquedaFocusLost
        // TODO add your handling code here:
        cargarlista();
    }//GEN-LAST:event_txtBusquedaFocusLost

    private void cargarlista() {
        // TODO Auto-generated method stub
        ResultSet rs = null;
        cbxTratamientos.removeAllItems();
        try {
            Conexion.Conectar();
            rs = ventanas.Conexion.link.createStatement().executeQuery("select TT.NOM_TRATA from PACIENTE_TRATAMIENTO PT, TIPO_TRATAMIENTO TT WHERE PT.COD_TRATAMIENTO = TT.COD_TRATAMIENTO AND TT.COD_TRATA_FACIAL = 1 AND PT.CEDULA = '" + txtBusqueda.getText() + "';");
            while (rs.next()) {
                String tmpStrObtenido = rs.getString(1);
                cbxTratamientos.addItem(tmpStrObtenido);
            }
            Conexion.Close();
            Conexion.Conectar();
        } catch (Exception e) {
            System.out.println("ERROR: falla al cargar los trataminetos");
        }

    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FichaNutricional.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FichaNutricional.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FichaNutricional.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FichaNutricional.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FichaNutricional().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBusqueda;
    private javax.swing.JMenu btnCargar;
    private javax.swing.JMenu btnGestionar;
    private javax.swing.JMenu btnImprimir;
    private javax.swing.JMenu btnRegresar;
    private javax.swing.JComboBox cbxTratamientos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField txtBusqueda;
    // End of variables declaration//GEN-END:variables
}
